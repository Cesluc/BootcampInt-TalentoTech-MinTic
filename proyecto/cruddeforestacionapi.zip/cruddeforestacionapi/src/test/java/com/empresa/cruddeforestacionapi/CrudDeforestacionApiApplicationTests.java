package com.empresa.cruddeforestacionapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDeforestacionApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
